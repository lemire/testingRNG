namespace PractRand {
	namespace Tests {
		class DistC6 : public TestBaseclass {
		public:
			DistC6 ( int length_ = 9, int unitsL_ = 0, 
				int bits_clipped_0_ = 1, 
				int bits_clipped_1_ = 0, 
				int bits_clipped_2_ = 0 ); 
			virtual void init( PractRand::RNGs::vRNG *known_good );
			virtual std::string get_name() const;
			virtual void get_results ( std::vector<TestResult> &results );

			virtual void test_blocks(TestBlock *data, int numblocks);

		protected:
			enum { ENABLE_REORDER = 1, ENABLE_8_BIT_BYPASS = 1 };
			//configuration:
			int length;
			int unitsL;
			int bits_clipped_0;
			int bits_clipped_1;
			int bits_clipped_2;
			//precalcs:
			int bits_per_sample;
			int size;
			Uint32 mask_pre;
			Uint32 lookup_table[ENABLE_8_BIT_BYPASS ? 256 : 65];//reorder_bits(reorder_codes(transform_bitcount( X ))) or reorder_bits(reorder_codes(transform_bitcount(count_bits8( X ))))
			Uint8 reorder_codes_table[64];
			Uint8 unreorder_codes_table[64];
			//state:
			int warmup;
			Uint32 last_index;
			VariableSizeCount<Uint8> counts;
			//internal helpers:
			virtual int transform_bitcount ( int bit_count ) const ;
			static Uint32 _reorder_bits ( Uint32 rcode, int bits_per_sample, int length ) ;
			Uint32 reorder_bits( Uint32 rcode ) const {return _reorder_bits(rcode, bits_per_sample, length);}
			Uint32 unreorder_bits ( Uint32 rbcode ) const {return _reorder_bits(rbcode, length, bits_per_sample);}
			Uint32 reorder_codes   ( Uint32 code ) const {return reorder_codes_table[code];}
			Uint32 unreorder_codes ( Uint32 rcode ) const {return unreorder_codes_table[rcode];}
			void generate_reorder_codes ();
			Uint32 _advance_index ( Uint32 index, int rbcode ) const {
				if (ENABLE_REORDER)
					return ((index & mask_pre) << 1) | rbcode ;
				else
					return ((index & mask_pre) << bits_per_sample) | rbcode ;
			}
			void advance_index ( int bit_count ) {
				last_index = _advance_index(last_index, lookup_table[bit_count]);}
		};
		class DistC7 : public DistC6 {
		public:
			DistC7(int length_ = 9, int unitsL_ = 0,
				int bits_clipped_0_ = 1,
				int bits_clipped_1_ = 0,
				int bits_clipped_2_ = 0
				);
			virtual void init(PractRand::RNGs::vRNG *known_good);
			virtual std::string get_name() const;
			virtual void get_results(std::vector<TestResult> &results);

			virtual void test_blocks(TestBlock *data, int numblocks);
		protected:
			//configuration:
			//precalcs:
			//state:
			bool odd;
			VariableSizeCount<Uint8> odd_counts;
			//internal helpers:
		};
		class SimpleClassifyWord : public TestBaseclass {
		public:
			/*
				broadly, every 16 bits gets classified down to just 3 bits, and an overlapping window of 8 such sets of 3 bits are fed in to a chi-squared test
				could do a different classification scheme down to 2 bits
				could also do a variant that operates on 32 bit words
				currently uncallibrated
			*/
			SimpleClassifyWord();
			virtual void init(PractRand::RNGs::vRNG *known_good);
			virtual std::string get_name() const;
			virtual void get_results(std::vector<TestResult> &results);

			virtual void test_blocks(TestBlock *data, int numblocks);
		protected:
			Uint8 word_to_code(Uint16 word);
			Uint32 word_to_reordered_code(Uint16 word);
			enum { CODE_BITS = 3, OVERLAP_WINDOW = 8, TOTAL_BITS = CODE_BITS * OVERLAP_WINDOW };
			Uint32 current;
			Uint8 lookup_half[256];
			Uint32 reordered_second_lookup[256];
			Uint8 second_lookup[256];
			Uint32 reorder_code[1 << CODE_BITS];
			Uint32 warmup;
			Uint32 reorder_mask;
			double root_probs[8];
			FixedSizeCount<Uint16, 1 << TOTAL_BITS> counts;
		};
	}//Tests
}//PractRand

#ifndef _PractRand_h
#define _PractRand_h

#include <string>
#include "PractRand/config.h"
#include "PractRand/rng_basics.h"
#include "PractRand/rng_helpers.h"

#endif //_PractRand_h

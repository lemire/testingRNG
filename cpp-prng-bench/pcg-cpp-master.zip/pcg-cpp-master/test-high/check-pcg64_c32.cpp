#define RNG pcg64_c32
#define TWO_ARG_INIT 1
#define AWKWARD_128BIT_CODE 1

#include "pcg-test-noadvance.cpp"


#define RNG pcg64
#define TWO_ARG_INIT 1

#include "pcg-test.cpp"

